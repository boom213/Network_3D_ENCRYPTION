// 
//
//  The tick svg was taken from font awesome, made by Dave Gandy
//
//